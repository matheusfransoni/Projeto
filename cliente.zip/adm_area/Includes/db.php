<?php

$con = mysqli_connect("mysql.hostinger.com.br","u403052679_proj","ninosuzy","u403052679_proj"); //conexão do banco de dados 

if (mysqli_connect_errno())
 {
	echo "Falha ao conectar com MySQL" . mysqli_connect_error();
 }
?>